  
<?php

$server = 'localhost';
$username = 'root';
$database = "big_market";
$password = '';

$dbco = new PDO("mysql:host=$server;dbname=$database",$username,$password);
$dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = $dbco->prepare("SELECT * FROM clients WHERE email = ? AND mdp= ?");
$sql->execute([$_POST['email'],$_POST['mdp']]);

$user = $sql->fetch();
if($user){
    session_start();
    header("Location: marche.php");
}
else{
             echo " Login ou mot de passe non valide <a href = 'connexion.php'>reessayez</a>";

}

?>
