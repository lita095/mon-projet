<?php
require("Header.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"
      integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="./style_produits.css">
    <title>Document</title>
</head>
<body>
<table  class="table">
     <thead>
     	<tr>
     	 <th>Nom Produit</th>
     	 <th>Prix</th>
     	 <th>Informations Additionnelles</th>
     	 <th>Action</th>
     	</tr>
     </thead>
     <tbody>
     	  <tr>
     	  	  <td data-label="Nom Produit">MacBook Air M1 huit</td>
     	  	  <td rowspan="2" data-label="Prix">1399.99</td>
     	  	  <td rowspan="2" data-label="Informations Additionnelles">peldi</td>
     	  	  <td rowspan="2" data-label="Action">
                     <div class="edit">
                        <a href=""><i class="fas fa-trash-alt"></i></a>
                        <a href=""><i class="fas fa-pen"></i></a>
                     </div>
                 </td>
     	  </tr>

           <tr>
            <td data-label="Nom Produit">MacBook Pro M1 13 pouces 8 cœurs</td>
            </td>
      </tr>
      <tr>
        <td data-label="Nom Produit"> MacBook Pro Intel</td>
        <td rowspan="2" data-label="Prix">1129.2$</td>
        <td rowspan="2" data-label="Informations Additionnelles"></td>
        <td rowspan="2" data-label="Action">
            <div class="edit">
                <a onclick="removeDummy();" href=""><i class="fas fa-trash-alt"></i></a>
                <a href=""><i class="fas fa-pen"></i></a>
            </div>
        </td>
  </tr>

  <tr>
    <td data-label="Nom Produit"> Macbook Pro 16 pouces </td>

 </tr>

<tr>
    <td data-label="Nom Produit"> MacBook Pro 14 pouces</td>
    <td rowspan="2" data-label="Prix">1679.9$</td>
    <td rowspan="2" data-label="Informations Additionnelles">patat</td>
    <td rowspan="2" data-label="Action">
        <div class="edit">
            <a href=""><i class="fas fa-trash-alt"></i></a>
            <a href=""><i class="fas fa-pen"></i></a>
        </div>
    </td>
</tr>

<tr>
    <td data-label="Nom Produit">MacBook Pro 13 pouces</td>
</tr>

<tr>
    <td data-label="Nom Produit">MacBook Pro Intel</td>
    <td rowspan="2" data-label="Prix">2979.99</td>
    <td rowspan="2" data-label="Informations Additionnelles">Val</td>
    <td rowspan="2" data-label="Action">
        <div class="edit">
            <a href=""><i class="fas fa-trash-alt"></i></a>
            <a href=""><i class="fas fa-pen"></i></a>
        </div>
    </td>
</tr>

<tr>
    <td data-label="Nom Produit"> MacBook Pro 15 pouces</td>
</tr>
     </tbody>
   </table>
</body>
</html>