<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="css\bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css.css">
    <style>
        #bi {  position: absolute;left: 100px; }
        form{
            margin-top: 100px;
            margin-left: 300px;
            width: 500px;
            position: absolute;
            top: 10px;
            border: 1px solid #CCC;
            padding: 20px;
        }
        button{
            margin-top: 10px;
            padding-right: 20px;
        }
        #connect{  font-size:40px;  font-family: cursive;  margin-top: 20px; }
        
        .line{
            padding:10px;
        }
        .footer{
            margin-top: 490px;
            text-align: center;
        }
        a{
            padding-right: 20px;
        }
    </style>
</head>
<body>
    <div align="center">
       <div id="connect">Connexion</div> 
   
    <div class="container">
        <form action="verification.php" method="post">
           
                <div class="form-group line">
                    <img src="market.png" width="100px" height="100px">

                </div>
                <div class="form-group line">
                <label class="form-label"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-envelope-fill " id="bi" viewBox="0 0 16 16">
  <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555zM0 4.697v7.104l5.803-3.558L0 4.697zM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757zm3.436-.586L16 11.801V4.697l-5.803 3.546z"/>
</svg><input type="text" class= "form-control" name="email" placeholder="votre login"></label>
            </div>

            <div class="form-group line">
                <label class="form-label"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-key" id="bi" viewBox="0 0 16 16">
  <path d="M0 8a4 4 0 0 1 7.465-2H14a.5.5 0 0 1 .354.146l1.5 1.5a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0L13 9.207l-.646.647a.5.5 0 0 1-.708 0L11 9.207l-.646.647a.5.5 0 0 1-.708 0L9 9.207l-.646.647A.5.5 0 0 1 8 10h-.535A4 4 0 0 1 0 8zm4-3a3 3 0 1 0 2.712 4.285A.5.5 0 0 1 7.163 9h.63l.853-.854a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.793-.793-1-1h-6.63a.5.5 0 0 1-.451-.285A3 3 0 0 0 4 5z"/>
  <path d="M4 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg> <input type="password" class= "form-control" name="mdp" placeholder="password"></label>
               
            </div>
            <div class="form-group line">
                <label><input type="checkbox" value="">Connexion permanente</label>
            </div>

            <div class="form-group line">
                <button class="btn btn-primary" type="submit">Connexion</button>
                <button class="btn btn-danger" typr="reset">Annuler</button>
            </div>
        </form>
        
    </div>
     </div>
     <div class="footer">
           <a href="Mot_de_passe_oublie.html">Mot de passe oublié</a>
           <a href="Cree_un_compte.html">Créer un compte</a>
        </div>
</body>
</html>