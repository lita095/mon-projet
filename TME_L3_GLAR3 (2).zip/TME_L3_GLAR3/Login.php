<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        form{
            margin: 0 auto;
            width: 500px;
            position: absolute;
            top: 10px;
            border: 1px solid #CCC;
            padding: 20px;
        }
        button{
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="traitement2.php" method="post">
            <div class="form-group">
                <label class="form-label">Login</label>
                <input type="text" class= "form-control" name="login" placeholder="votre login">
            </div>

            <div class="form-group">
                <label class="form-label">mot de pass</label>
                <input type="password" class= "form-control" name="pwd" placeholder="password">
            </div>

            <div class="form-group">
                <button class="btn btn-primary" type="submit">Connexion</button>
                <button class="btn btn-danger" typr="reset">Annuler</button>
            </div>
        </form>
    </div>
</body>
</html>