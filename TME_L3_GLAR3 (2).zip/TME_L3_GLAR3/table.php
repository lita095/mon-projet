<?php
$servername="localhost";
$username="root";
$password="";
$database="big_market";
try{
	//On etabli la connexion
	$db=new PDO("mysql:host=$servername;dbname=$database",$username,$password);
	//On definit le mode d'erreur de PDO sur exception
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	//On cree la base de donnée
	$sql="CREATE TABLE clients(
      id int UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      nom Varchar(30) NOT NULL,
      prenom Varchar(30) NOT NULL,
      email Varchar(45) NOT NULL,
      mdp Varchar(30) NOT NULL  
)";
	$db->exec($sql);
	echo "TABLE CREE";
	

}
	//On capture les exceptions si une exception est lancée et on affiche les infos relatives à celle ci

	catch(PDOException $e){
		echo "Erreur: ".$e->getMessage();
	}



 ?>