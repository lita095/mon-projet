<?php
$servername = "localhost";
$username = 'root';
$password = "";
$base_de_donne = "big_market";
$dbco = new PDO("mysql:host=$servername;dbname=$base_de_donne", $username, $password);
// 1. prepare la requete
$req = $dbco->query('SELECT * FROM `utilisateur`');
// 2. execute la requete
$req->execute();
// 3. recupere les donnees
// while ($d = $req->fetch()){
//    var_dump($d);
//    echo '<br>Ligne<br>';
//}
$donnees = $req->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";
//var_dump($donnees);
//echo "</pre>";
?><div>
    <h1> List des utilisateurs</h1>
    <table border="1">
        <thead>
            <tr>
                <th>id</th>
                <th>nom</th>
                <th>prenom</th>
                <th>Email</th>
                <th>telephone</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($donnees as $key => $value) { ?> <tr>
                    <th><?= $value['id'] ?></th>
                    <th><?= $value['nom'] ?></th>
                    <th><?= $value['prenom'] ?></th>
                    <th><?= $value['email'] ?></th>
                    <th><?= $value['telephone'] ?></th>
                </tr>
            <?php } ?> </tbody>
    </table>
</div>