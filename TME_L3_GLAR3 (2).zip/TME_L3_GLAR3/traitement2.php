<?php
if(isset($_POST['login']) && !empty($_POST['login']))
{
    if($_POST['login'] === 'hamedy'&& $_POST['pwd']==='passer')
    {
        header(header: 'location: index.php');
    }else{
        header(header: 'location: Login.php');
    }
}


?>